define(function() {
	return {
		a:123,
		b:456
	}
})